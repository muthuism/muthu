package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.Pojo.UserPojo;
import com.example.demo.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {
	
	@Autowired
	private UserService userService;

	@Test
	public void contextLoads() {
	}

	@Test
	public UserPojo crudService() {
		UserPojo user =new UserPojo();
		user.setBirthDate("02-MAR-2980");
		user.setEmail("john.smith@gmail.com");
		user.setFname("john");
		user.setLname("Smith");
		user.setOperation("Create");
		user.setPincode(123456);
		
	
		
		user=userService.crudService(user);
		assertEquals(user.getErrorCode(), "101");
	  
		return user;		
		
	}
	

	@Test
	public UserPojo crudServic() {
		UserPojo user =new UserPojo();
		user.setBirthDate("02-MAR-2980");
		user.setEmail("john.smith@gmail.com");
		user.setFname("john");
		user.setLname("Smith");
		user.setOperation("Update");
		user.setPincode(123456);
		
	
		
		user=userService.crudService(user);
		assertEquals(user.getErrorCode(), "101");
	  
		return user;		
		
	}
}
