package com.example.demo.service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Pojo.UserPojo;
import com.example.demo.service.UserService;

@Service
public class UserServieImpl implements UserService {

	@Autowired
	private UserPojo user;

	@Override
	public UserPojo crudService(UserPojo user) {

		if (user != null) {

			if (user.getOperation() != null && "Create".equalsIgnoreCase(user.getOperation())) {
				List<UserPojo> liUserPojo = new ArrayList<>();
				liUserPojo.add(user);
				UserPojo userPojo = new UserPojo();
				userPojo.setId("1234%23");
				userPojo.setErrorCode("101");
				userPojo.setErrormessage("Created Successfully");

				return userPojo;
			} else if (user.getOperation() != null && "Update".equalsIgnoreCase(user.getOperation())) {

				UserPojo userPojo = new UserPojo();
				userPojo.setErrorCode("102");
				userPojo.setErrormessage("Updated Successfully");

				return userPojo;
			} else if (user.getOperation() != null && "Delete".equalsIgnoreCase(user.getOperation())) {

				UserPojo userPojo = new UserPojo();
				userPojo.setErrorCode("103");
				userPojo.setErrormessage("Deleted Successfully");
				return userPojo;

			}
		}

		return null;
	}

}
