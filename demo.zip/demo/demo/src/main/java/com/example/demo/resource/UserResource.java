package com.example.demo.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Pojo.UserPojo;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/resource")
public class UserResource {

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/user", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserPojo> crudExample(@RequestBody UserPojo userPojo,@RequestHeader HttpHeaders http) {

		UserPojo user = userService.crudService(userPojo);

		return new ResponseEntity<>(user, HttpStatus.OK);

	}

}
