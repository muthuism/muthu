package com.example.demo.Pojo;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class UserPojo {

	String Id;
	String fname;
	String lname;
	String email;
	Integer pincode;
	String birthDate;
	boolean isActive;
	String operation;
	String errormessage;
	String errorCode;

	public UserPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserPojo(String id, String fname, String lname, String email, Integer pincode, String birthDate,
			boolean isActive) {
		super();
		Id = id;
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.pincode = pincode;
		this.birthDate = birthDate;
		this.isActive = isActive;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}


	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getErrormessage() {
		return errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
