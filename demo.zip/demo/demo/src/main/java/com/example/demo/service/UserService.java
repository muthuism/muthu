package com.example.demo.service;

import com.example.demo.Pojo.UserPojo;

public interface UserService {

	public UserPojo crudService(UserPojo user);

}
